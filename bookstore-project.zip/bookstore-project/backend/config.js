export const PORT = 5555;

export const mongoDBURL = 'mongodb://localhost:27017/bookstore'
//you need to create database for yourself and set login and password in provided places 
